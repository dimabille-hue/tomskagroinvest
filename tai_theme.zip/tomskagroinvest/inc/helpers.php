<?php

if (!defined('ABSPATH')) {
	exit;
}

/*
|--------------------------------------------------------------------------
| Логотип сайта
|--------------------------------------------------------------------------
*/

function tai_logo()
{
	$logo = carbon_get_theme_option('header_logo');

	if ($logo) {

		echo wp_get_attachment_image(
			$logo,
			'full'
		);

		return;
	}

	the_custom_logo();
}

/*
|--------------------------------------------------------------------------
| Телефон
|--------------------------------------------------------------------------
*/

function tai_phone()
{
	return carbon_get_theme_option('tai_phone');
}

function tai_phone_href()
{
	return preg_replace(
		'/[^0-9+]/',
		'',
		tai_phone()
	);
}

/*
|--------------------------------------------------------------------------
| Email
|--------------------------------------------------------------------------
*/

function tai_email()
{
	return carbon_get_theme_option('tai_email');
}

/*
|--------------------------------------------------------------------------
| Адрес
|--------------------------------------------------------------------------
*/

function tai_address()
{
	return carbon_get_theme_option('tai_address');
}

/*
|--------------------------------------------------------------------------
| Режим работы
|--------------------------------------------------------------------------
*/

function tai_worktime()
{
	return carbon_get_theme_option('tai_worktime');
}

/*
|--------------------------------------------------------------------------
| Изображение записи
|--------------------------------------------------------------------------
*/

function tai_thumbnail($size = 'large')
{
	if (has_post_thumbnail()) {

		the_post_thumbnail($size);

		return;
	}

	printf(
		'<img src="%s/assets/images/no-image.jpg" alt="%s">',
		esc_url(TAI_THEME_URI),
		esc_attr(get_the_title())
	);
}

/*
|--------------------------------------------------------------------------
| URL вложения
|--------------------------------------------------------------------------
*/

function tai_file_url($id)
{
	if (!$id) {
		return '';
	}

	return wp_get_attachment_url($id);
}

/*
|--------------------------------------------------------------------------
| Размер файла
|--------------------------------------------------------------------------
*/

function tai_file_size($id)
{
	if (!$id) {
		return '';
	}

	$file = get_attached_file($id);

	if (!$file || !file_exists($file)) {
		return '';
	}

	return size_format(
		filesize($file),
		2
	);
}

/*
|--------------------------------------------------------------------------
| Дата
|--------------------------------------------------------------------------
*/

function tai_date($format = '')
{
	return get_the_date(
		$format ?: get_option('date_format')
	);
}

/*
|--------------------------------------------------------------------------
| Получение изображения Carbon Fields
|--------------------------------------------------------------------------
*/

function tai_image($id, $size = 'large')
{
	if (!$id) {
		return '';
	}

	return wp_get_attachment_image(
		$id,
		$size
	);
}

/*
|--------------------------------------------------------------------------
| Получение значения Carbon Theme Option
|--------------------------------------------------------------------------
*/

function tai_option($key, $default = '')
{
	if (!function_exists('carbon_get_theme_option')) {
		return $default;
	}

	$value = carbon_get_theme_option($key);

	return $value !== '' ? $value : $default;
}
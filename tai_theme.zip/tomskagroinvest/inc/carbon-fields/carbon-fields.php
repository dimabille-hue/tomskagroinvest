<?php

if (!defined('ABSPATH')) {
	exit;
}

use Carbon_Fields\Carbon_Fields;

add_action(
	'after_setup_theme',
	function () {

		Carbon_Fields::boot();

	}
);

require_once __DIR__ . '/theme-options.php';

require_once __DIR__ . '/post-meta/projects.php';
require_once __DIR__ . '/post-meta/documents.php';
require_once __DIR__ . '/post-meta/events.php';
require_once __DIR__ . '/post-meta/activities.php';
require_once __DIR__ . '/post-meta/partners.php';
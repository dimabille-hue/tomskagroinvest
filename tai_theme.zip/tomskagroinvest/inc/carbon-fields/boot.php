<?php

if (!defined('ABSPATH')) {
	exit;
}

/*
|--------------------------------------------------------------------------
| Theme Options
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/theme-options.php';

/*
|--------------------------------------------------------------------------
| Post Meta
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/post-meta/documents.php';

require_once __DIR__ . '/post-meta/projects.php';

require_once __DIR__ . '/post-meta/activities.php';

require_once __DIR__ . '/post-meta/events.php';